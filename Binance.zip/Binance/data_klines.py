
import pandas as pd
from binance.client import Client
import config
import ta



client= Client(config.apiKey,config.apiSecurity)
print("logged in")
#info=client.get_account()

klinesT = Client().get_historical_klines("BTCUSDT", Client.KLINE_INTERVAL_1HOUR, "01 April 2022")
df = pd.DataFrame(klinesT, columns = ['Open time','Open','High','Low','Close','Volume','Close time','Quote asset volume','Number of trades','Taker buy base asset volume','Taker buy quote asset volume','Ignore'])

#Nettoyage données inutiles

del df['Close time']
del df['Quote asset volume']
del df['Number of trades']
del df['Taker buy base asset volume']
del df['Taker buy quote asset volume']
del df['Ignore']

df['Close'] = pd.to_numeric(df['Close'])
df['High'] = pd.to_numeric(df['High'])
df['Low'] = pd.to_numeric(df['Low'])
df['Open'] = pd.to_numeric(df['Open'])

#Conversion du temps

df['Open time']= pd.to_datetime(df['Open time'], unit='ms')

#Définition des moyennes mobiles (SMA)
df['SMA100'] = ta.trend.sma_indicator(df['Close'], 100)
df['SMA200'] = ta.trend.sma_indicator(df['Close'], 200)
print(df)

#Stokage et mise à jour de la bdd
import sqlite3

cxtn = sqlite3.connect('BTCUSDTstream.db')
df.to_sql(name='my_table', con=cxtn, if_exists='replace', index=False)
df.to_csv("crypto_streaming.csv", index=False)