#python3 crypto_dashboard.py
from dash import Dash, dcc, html
import plotly.express as px
import pandas as pd
from dash.dependencies import Input, Output

app = Dash(__name__)

colors = {
    'background': '#111111',
    'text': '#7FDBFF'
}

df = pd.read_csv("crypto_streaming.csv")

#fig_1 = px.line(x=df['Open time'], y=df['High'],title='High values data',labels={'x':'Open time','y':'High'})

#fig_2 = px.line(x=df['Open time'], y=df['SMA200'], title ='SMA values data',labels={'x':'Open time','y':'SMA'})

app.layout = html.Div(style={'backgroundColor': colors['background']}, children=[
    html.H1(
        children='CRYPTO STREAMING DASHBOARD',
        style={
            'textAlign': 'center',
            'color': colors['text']
        }
    ),

    html.Div(children='Web application framework for streaming data.', style={
        'textAlign': 'center',
        'color': colors['text']
    }),
    html.Div(dcc.Dropdown(id = 'Dropdown',
                        options= [{'label': 'High value', 'value': 'High'},
                                  {'label': 'Low value', 'value': 'Low'},
                                  {'label': 'Volume', 'value': 'Volume'},
                                  {'label': 'SMA100', 'value': 'SMA100'}],
                        value= 'High'
    )),

    dcc.Graph(
        id='graph_1',
    ),
])

@app.callback(Output(component_id='graph_1', component_property='figure'),
            [Input(component_id='Dropdown', component_property='value')])
def update_graph(indicator):
    # Création de la figure plotly
    fig = px.line(df, x=df['Open time'],
                        y=indicator,
                    )
    return fig

if __name__ == '__main__':
    app.run_server(debug=True)