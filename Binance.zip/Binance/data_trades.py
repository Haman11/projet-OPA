import pandas as pd
from pandas import DataFrame
from binance.client import Client
import config


client= Client(config.apiKey,config.apiSecurity)
print("logged in")


trades = client.get_historical_trades(symbol='BTCUSDT')

df = pd.DataFrame(trades, columns = ['id','price','qty','quoteQty','time','isBuyerMaker','isBestMatch'])

#Conversion du temps

df = df.set_index(df['time'])
df.index = pd.to_datetime(df.index, unit='ms')
del df['time']

print(df)