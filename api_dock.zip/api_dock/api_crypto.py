from fastapi import FastAPI
import pandas as pd



api = FastAPI(
    title='CRYPTO API',
    description="My API powered by FastAPI.",
    version="1.0.1"
)
crypto_data = pd.read_csv('crypto_streaming.csv')
crypto_data=crypto_data.fillna('') 
#Verification de la fonctionnalité de l'API
@api.get('/')
def get_index():
    """Returns API functionnality
    """
    return {'Notre API est fonctionnelle'}

@api.get('/crypto_data')
def get_data():
    return crypto_data

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(api, host="0.0.0.0", port=8000)